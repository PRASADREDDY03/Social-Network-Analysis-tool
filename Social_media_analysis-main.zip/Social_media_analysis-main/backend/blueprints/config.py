# For local MongoDB Compass connection
MONGODB_URI = "mongodb://localhost:27017/"

# YouTube API Configuration
YOUTUBE_API_KEY = "AIzaSyCrzhOfOwbaqTZZF6uTMWdN1VdE1p1R4pQ"